import { Component, OnInit } from '@angular/core';
import {Contact} from '../../shared/model/contact';
import {Users} from '../../shared/model/users';
import {HttpClient} from '@angular/common/http';
import {UserService} from '../../shared/services/user.service';
import {MessageService} from 'primeng/api';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
user: Users = new Users();
  confirmPWD: string;
  visible = true;
roles: any[];
selectedRole: any;

  constructor(private userService: UserService, private messageService: MessageService, private router: Router,
              private activatedRoot: ActivatedRoute) { }

  ngOnInit() {
    this.roles = [{role: 'Admin'}, {role: 'User'}];
    const id = this.activatedRoot.snapshot.paramMap.get('id');
    if(id !== null){
      this.userService.findById(id).subscribe(res=> {
        this.user = res;
        if(this.user.role === 'Admin'){
          this.selectedRole=this.roles[0];
        }else { this.selectedRole=this.roles[1];}
        this.visible = false;
      }, ex=>{
        console.log(ex);
      })
    }
  }
  ajouter() {
    this.user.role = this.selectedRole.role;
this.userService.save(this.user).subscribe( res => {if (res.success) {
this.router.navigate(['/list-user']);
  this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
} else {
  this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
}
}, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });

  }
  modifer() {
    this.userService.update(this.user).subscribe( res => {if (res.success) {
      this.router.navigate(['/list-user']);
      this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
    } else {
      this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
    }
    }, err => {this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'}); });

  }


}
