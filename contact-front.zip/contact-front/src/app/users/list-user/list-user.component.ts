import {Component, OnInit} from '@angular/core';
import {UserService} from '../../shared/services/user.service';
import {ConfirmationService, MessageService} from 'primeng/api';
import {Users} from '../../shared/model/users';
import {Router} from '@angular/router';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {
  users: Users[];

  constructor(private userService: UserService, private messageService: MessageService, private confirmationService: ConfirmationService,
              private router: Router) {
  }

  ngOnInit() {
    this.getAll();
  }

  getAll() {
    this.userService.getAll().subscribe(data => {
        this.users = data;
      }, err => {
        console.log(err);
      }
    );
  }

  public supprimer(user) {
    this.confirmationService.confirm({
      header: 'confirmation',
      message: 'voulez vous supprimer',
      accept: () => {
        this.userService.delete(user.id).subscribe(res => {
          if (res.success) {
            this.messageService.add({severity: 'success', summary: 'success', detail: res.message});
            this.getAll();
          } else {
            this.messageService.add({severity: 'warn', summary: 'Attention', detail: res.message});
          }
        }, err => {
          this.messageService.add({severity: 'error', summary: 'Erreur', detail: 'Opération non effectuée'});
        });
      }
    });
  }
  public editer(user){
    this.router.navigate(['/edit-user', user.id]);
  }
}
