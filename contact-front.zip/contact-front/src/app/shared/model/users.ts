import {Contact} from './contact';

export class Users extends Contact {
  username: string;
  password: string;
  role: string;
}
