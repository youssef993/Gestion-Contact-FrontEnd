export class Contact {

id: number;
nom: string;
prenom: string;
email: string;
}
